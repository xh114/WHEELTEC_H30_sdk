// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CAR_CONTROL_MSGS__MSG__CAR_FEEDBACK_HPP_
#define CAR_CONTROL_MSGS__MSG__CAR_FEEDBACK_HPP_

#include "car_control_msgs/msg/detail/car_feedback__struct.hpp"
#include "car_control_msgs/msg/detail/car_feedback__builder.hpp"
#include "car_control_msgs/msg/detail/car_feedback__traits.hpp"
#include "car_control_msgs/msg/detail/car_feedback__type_support.hpp"

#endif  // CAR_CONTROL_MSGS__MSG__CAR_FEEDBACK_HPP_
