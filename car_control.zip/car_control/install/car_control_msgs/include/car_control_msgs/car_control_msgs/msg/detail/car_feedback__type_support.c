// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from car_control_msgs:msg/CarFeedback.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "car_control_msgs/msg/detail/car_feedback__rosidl_typesupport_introspection_c.h"
#include "car_control_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "car_control_msgs/msg/detail/car_feedback__functions.h"
#include "car_control_msgs/msg/detail/car_feedback__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  car_control_msgs__msg__CarFeedback__init(message_memory);
}

void car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_fini_function(void * message_memory)
{
  car_control_msgs__msg__CarFeedback__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_message_member_array[6] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(car_control_msgs__msg__CarFeedback, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "linear_velocity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(car_control_msgs__msg__CarFeedback, linear_velocity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "angular_velocity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(car_control_msgs__msg__CarFeedback, angular_velocity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "left_wheel_velocity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(car_control_msgs__msg__CarFeedback, left_wheel_velocity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "right_wheel_velocity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(car_control_msgs__msg__CarFeedback, right_wheel_velocity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "frame_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(car_control_msgs__msg__CarFeedback, frame_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_message_members = {
  "car_control_msgs__msg",  // message namespace
  "CarFeedback",  // message name
  6,  // number of fields
  sizeof(car_control_msgs__msg__CarFeedback),
  car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_message_member_array,  // message members
  car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_init_function,  // function to initialize message memory (memory has to be allocated)
  car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_message_type_support_handle = {
  0,
  &car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_car_control_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, car_control_msgs, msg, CarFeedback)() {
  car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_message_type_support_handle.typesupport_identifier) {
    car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &car_control_msgs__msg__CarFeedback__rosidl_typesupport_introspection_c__CarFeedback_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
