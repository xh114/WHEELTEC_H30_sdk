// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from car_control_msgs:msg/CarFeedback.idl
// generated code does not contain a copyright notice
#include "car_control_msgs/msg/detail/car_feedback__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
car_control_msgs__msg__CarFeedback__init(car_control_msgs__msg__CarFeedback * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    car_control_msgs__msg__CarFeedback__fini(msg);
    return false;
  }
  // linear_velocity
  // angular_velocity
  // left_wheel_velocity
  // right_wheel_velocity
  // frame_type
  return true;
}

void
car_control_msgs__msg__CarFeedback__fini(car_control_msgs__msg__CarFeedback * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // linear_velocity
  // angular_velocity
  // left_wheel_velocity
  // right_wheel_velocity
  // frame_type
}

bool
car_control_msgs__msg__CarFeedback__are_equal(const car_control_msgs__msg__CarFeedback * lhs, const car_control_msgs__msg__CarFeedback * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // linear_velocity
  if (lhs->linear_velocity != rhs->linear_velocity) {
    return false;
  }
  // angular_velocity
  if (lhs->angular_velocity != rhs->angular_velocity) {
    return false;
  }
  // left_wheel_velocity
  if (lhs->left_wheel_velocity != rhs->left_wheel_velocity) {
    return false;
  }
  // right_wheel_velocity
  if (lhs->right_wheel_velocity != rhs->right_wheel_velocity) {
    return false;
  }
  // frame_type
  if (lhs->frame_type != rhs->frame_type) {
    return false;
  }
  return true;
}

bool
car_control_msgs__msg__CarFeedback__copy(
  const car_control_msgs__msg__CarFeedback * input,
  car_control_msgs__msg__CarFeedback * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // linear_velocity
  output->linear_velocity = input->linear_velocity;
  // angular_velocity
  output->angular_velocity = input->angular_velocity;
  // left_wheel_velocity
  output->left_wheel_velocity = input->left_wheel_velocity;
  // right_wheel_velocity
  output->right_wheel_velocity = input->right_wheel_velocity;
  // frame_type
  output->frame_type = input->frame_type;
  return true;
}

car_control_msgs__msg__CarFeedback *
car_control_msgs__msg__CarFeedback__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  car_control_msgs__msg__CarFeedback * msg = (car_control_msgs__msg__CarFeedback *)allocator.allocate(sizeof(car_control_msgs__msg__CarFeedback), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(car_control_msgs__msg__CarFeedback));
  bool success = car_control_msgs__msg__CarFeedback__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
car_control_msgs__msg__CarFeedback__destroy(car_control_msgs__msg__CarFeedback * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    car_control_msgs__msg__CarFeedback__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
car_control_msgs__msg__CarFeedback__Sequence__init(car_control_msgs__msg__CarFeedback__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  car_control_msgs__msg__CarFeedback * data = NULL;

  if (size) {
    data = (car_control_msgs__msg__CarFeedback *)allocator.zero_allocate(size, sizeof(car_control_msgs__msg__CarFeedback), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = car_control_msgs__msg__CarFeedback__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        car_control_msgs__msg__CarFeedback__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
car_control_msgs__msg__CarFeedback__Sequence__fini(car_control_msgs__msg__CarFeedback__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      car_control_msgs__msg__CarFeedback__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

car_control_msgs__msg__CarFeedback__Sequence *
car_control_msgs__msg__CarFeedback__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  car_control_msgs__msg__CarFeedback__Sequence * array = (car_control_msgs__msg__CarFeedback__Sequence *)allocator.allocate(sizeof(car_control_msgs__msg__CarFeedback__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = car_control_msgs__msg__CarFeedback__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
car_control_msgs__msg__CarFeedback__Sequence__destroy(car_control_msgs__msg__CarFeedback__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    car_control_msgs__msg__CarFeedback__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
car_control_msgs__msg__CarFeedback__Sequence__are_equal(const car_control_msgs__msg__CarFeedback__Sequence * lhs, const car_control_msgs__msg__CarFeedback__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!car_control_msgs__msg__CarFeedback__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
car_control_msgs__msg__CarFeedback__Sequence__copy(
  const car_control_msgs__msg__CarFeedback__Sequence * input,
  car_control_msgs__msg__CarFeedback__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(car_control_msgs__msg__CarFeedback);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    car_control_msgs__msg__CarFeedback * data =
      (car_control_msgs__msg__CarFeedback *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!car_control_msgs__msg__CarFeedback__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          car_control_msgs__msg__CarFeedback__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!car_control_msgs__msg__CarFeedback__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
