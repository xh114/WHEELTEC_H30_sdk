// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from car_control_msgs:msg/CarFeedback.idl
// generated code does not contain a copyright notice

#ifndef CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__BUILDER_HPP_
#define CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "car_control_msgs/msg/detail/car_feedback__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace car_control_msgs
{

namespace msg
{

namespace builder
{

class Init_CarFeedback_frame_type
{
public:
  explicit Init_CarFeedback_frame_type(::car_control_msgs::msg::CarFeedback & msg)
  : msg_(msg)
  {}
  ::car_control_msgs::msg::CarFeedback frame_type(::car_control_msgs::msg::CarFeedback::_frame_type_type arg)
  {
    msg_.frame_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::car_control_msgs::msg::CarFeedback msg_;
};

class Init_CarFeedback_right_wheel_velocity
{
public:
  explicit Init_CarFeedback_right_wheel_velocity(::car_control_msgs::msg::CarFeedback & msg)
  : msg_(msg)
  {}
  Init_CarFeedback_frame_type right_wheel_velocity(::car_control_msgs::msg::CarFeedback::_right_wheel_velocity_type arg)
  {
    msg_.right_wheel_velocity = std::move(arg);
    return Init_CarFeedback_frame_type(msg_);
  }

private:
  ::car_control_msgs::msg::CarFeedback msg_;
};

class Init_CarFeedback_left_wheel_velocity
{
public:
  explicit Init_CarFeedback_left_wheel_velocity(::car_control_msgs::msg::CarFeedback & msg)
  : msg_(msg)
  {}
  Init_CarFeedback_right_wheel_velocity left_wheel_velocity(::car_control_msgs::msg::CarFeedback::_left_wheel_velocity_type arg)
  {
    msg_.left_wheel_velocity = std::move(arg);
    return Init_CarFeedback_right_wheel_velocity(msg_);
  }

private:
  ::car_control_msgs::msg::CarFeedback msg_;
};

class Init_CarFeedback_angular_velocity
{
public:
  explicit Init_CarFeedback_angular_velocity(::car_control_msgs::msg::CarFeedback & msg)
  : msg_(msg)
  {}
  Init_CarFeedback_left_wheel_velocity angular_velocity(::car_control_msgs::msg::CarFeedback::_angular_velocity_type arg)
  {
    msg_.angular_velocity = std::move(arg);
    return Init_CarFeedback_left_wheel_velocity(msg_);
  }

private:
  ::car_control_msgs::msg::CarFeedback msg_;
};

class Init_CarFeedback_linear_velocity
{
public:
  explicit Init_CarFeedback_linear_velocity(::car_control_msgs::msg::CarFeedback & msg)
  : msg_(msg)
  {}
  Init_CarFeedback_angular_velocity linear_velocity(::car_control_msgs::msg::CarFeedback::_linear_velocity_type arg)
  {
    msg_.linear_velocity = std::move(arg);
    return Init_CarFeedback_angular_velocity(msg_);
  }

private:
  ::car_control_msgs::msg::CarFeedback msg_;
};

class Init_CarFeedback_header
{
public:
  Init_CarFeedback_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CarFeedback_linear_velocity header(::car_control_msgs::msg::CarFeedback::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_CarFeedback_linear_velocity(msg_);
  }

private:
  ::car_control_msgs::msg::CarFeedback msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::car_control_msgs::msg::CarFeedback>()
{
  return car_control_msgs::msg::builder::Init_CarFeedback_header();
}

}  // namespace car_control_msgs

#endif  // CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__BUILDER_HPP_
