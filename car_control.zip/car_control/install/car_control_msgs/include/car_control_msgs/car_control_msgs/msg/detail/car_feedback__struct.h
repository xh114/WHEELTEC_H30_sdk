// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from car_control_msgs:msg/CarFeedback.idl
// generated code does not contain a copyright notice

#ifndef CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__STRUCT_H_
#define CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/CarFeedback in the package car_control_msgs.
typedef struct car_control_msgs__msg__CarFeedback
{
  std_msgs__msg__Header header;
  float linear_velocity;
  float angular_velocity;
  float left_wheel_velocity;
  float right_wheel_velocity;
  uint8_t frame_type;
} car_control_msgs__msg__CarFeedback;

// Struct for a sequence of car_control_msgs__msg__CarFeedback.
typedef struct car_control_msgs__msg__CarFeedback__Sequence
{
  car_control_msgs__msg__CarFeedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} car_control_msgs__msg__CarFeedback__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__STRUCT_H_
