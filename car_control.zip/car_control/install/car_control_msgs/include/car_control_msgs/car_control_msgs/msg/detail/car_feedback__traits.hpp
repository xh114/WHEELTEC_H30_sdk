// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from car_control_msgs:msg/CarFeedback.idl
// generated code does not contain a copyright notice

#ifndef CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__TRAITS_HPP_
#define CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "car_control_msgs/msg/detail/car_feedback__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace car_control_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const CarFeedback & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: linear_velocity
  {
    out << "linear_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.linear_velocity, out);
    out << ", ";
  }

  // member: angular_velocity
  {
    out << "angular_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.angular_velocity, out);
    out << ", ";
  }

  // member: left_wheel_velocity
  {
    out << "left_wheel_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.left_wheel_velocity, out);
    out << ", ";
  }

  // member: right_wheel_velocity
  {
    out << "right_wheel_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.right_wheel_velocity, out);
    out << ", ";
  }

  // member: frame_type
  {
    out << "frame_type: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_type, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CarFeedback & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: linear_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "linear_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.linear_velocity, out);
    out << "\n";
  }

  // member: angular_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "angular_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.angular_velocity, out);
    out << "\n";
  }

  // member: left_wheel_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_wheel_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.left_wheel_velocity, out);
    out << "\n";
  }

  // member: right_wheel_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_wheel_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.right_wheel_velocity, out);
    out << "\n";
  }

  // member: frame_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_type: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_type, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CarFeedback & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace car_control_msgs

namespace rosidl_generator_traits
{

[[deprecated("use car_control_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const car_control_msgs::msg::CarFeedback & msg,
  std::ostream & out, size_t indentation = 0)
{
  car_control_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use car_control_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const car_control_msgs::msg::CarFeedback & msg)
{
  return car_control_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<car_control_msgs::msg::CarFeedback>()
{
  return "car_control_msgs::msg::CarFeedback";
}

template<>
inline const char * name<car_control_msgs::msg::CarFeedback>()
{
  return "car_control_msgs/msg/CarFeedback";
}

template<>
struct has_fixed_size<car_control_msgs::msg::CarFeedback>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<car_control_msgs::msg::CarFeedback>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<car_control_msgs::msg::CarFeedback>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__TRAITS_HPP_
