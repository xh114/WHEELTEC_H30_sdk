// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from car_control_msgs:msg/CarFeedback.idl
// generated code does not contain a copyright notice

#ifndef CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__STRUCT_HPP_
#define CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__car_control_msgs__msg__CarFeedback __attribute__((deprecated))
#else
# define DEPRECATED__car_control_msgs__msg__CarFeedback __declspec(deprecated)
#endif

namespace car_control_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CarFeedback_
{
  using Type = CarFeedback_<ContainerAllocator>;

  explicit CarFeedback_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->linear_velocity = 0.0f;
      this->angular_velocity = 0.0f;
      this->left_wheel_velocity = 0.0f;
      this->right_wheel_velocity = 0.0f;
      this->frame_type = 0;
    }
  }

  explicit CarFeedback_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->linear_velocity = 0.0f;
      this->angular_velocity = 0.0f;
      this->left_wheel_velocity = 0.0f;
      this->right_wheel_velocity = 0.0f;
      this->frame_type = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _linear_velocity_type =
    float;
  _linear_velocity_type linear_velocity;
  using _angular_velocity_type =
    float;
  _angular_velocity_type angular_velocity;
  using _left_wheel_velocity_type =
    float;
  _left_wheel_velocity_type left_wheel_velocity;
  using _right_wheel_velocity_type =
    float;
  _right_wheel_velocity_type right_wheel_velocity;
  using _frame_type_type =
    uint8_t;
  _frame_type_type frame_type;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__linear_velocity(
    const float & _arg)
  {
    this->linear_velocity = _arg;
    return *this;
  }
  Type & set__angular_velocity(
    const float & _arg)
  {
    this->angular_velocity = _arg;
    return *this;
  }
  Type & set__left_wheel_velocity(
    const float & _arg)
  {
    this->left_wheel_velocity = _arg;
    return *this;
  }
  Type & set__right_wheel_velocity(
    const float & _arg)
  {
    this->right_wheel_velocity = _arg;
    return *this;
  }
  Type & set__frame_type(
    const uint8_t & _arg)
  {
    this->frame_type = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    car_control_msgs::msg::CarFeedback_<ContainerAllocator> *;
  using ConstRawPtr =
    const car_control_msgs::msg::CarFeedback_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<car_control_msgs::msg::CarFeedback_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<car_control_msgs::msg::CarFeedback_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      car_control_msgs::msg::CarFeedback_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<car_control_msgs::msg::CarFeedback_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      car_control_msgs::msg::CarFeedback_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<car_control_msgs::msg::CarFeedback_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<car_control_msgs::msg::CarFeedback_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<car_control_msgs::msg::CarFeedback_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__car_control_msgs__msg__CarFeedback
    std::shared_ptr<car_control_msgs::msg::CarFeedback_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__car_control_msgs__msg__CarFeedback
    std::shared_ptr<car_control_msgs::msg::CarFeedback_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CarFeedback_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->linear_velocity != other.linear_velocity) {
      return false;
    }
    if (this->angular_velocity != other.angular_velocity) {
      return false;
    }
    if (this->left_wheel_velocity != other.left_wheel_velocity) {
      return false;
    }
    if (this->right_wheel_velocity != other.right_wheel_velocity) {
      return false;
    }
    if (this->frame_type != other.frame_type) {
      return false;
    }
    return true;
  }
  bool operator!=(const CarFeedback_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CarFeedback_

// alias to use template instance with default allocator
using CarFeedback =
  car_control_msgs::msg::CarFeedback_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace car_control_msgs

#endif  // CAR_CONTROL_MSGS__MSG__DETAIL__CAR_FEEDBACK__STRUCT_HPP_
