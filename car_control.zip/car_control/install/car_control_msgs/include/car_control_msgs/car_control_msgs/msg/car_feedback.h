// generated from rosidl_generator_c/resource/idl.h.em
// with input from car_control_msgs:msg/CarFeedback.idl
// generated code does not contain a copyright notice

#ifndef CAR_CONTROL_MSGS__MSG__CAR_FEEDBACK_H_
#define CAR_CONTROL_MSGS__MSG__CAR_FEEDBACK_H_

#include "car_control_msgs/msg/detail/car_feedback__struct.h"
#include "car_control_msgs/msg/detail/car_feedback__functions.h"
#include "car_control_msgs/msg/detail/car_feedback__type_support.h"

#endif  // CAR_CONTROL_MSGS__MSG__CAR_FEEDBACK_H_
