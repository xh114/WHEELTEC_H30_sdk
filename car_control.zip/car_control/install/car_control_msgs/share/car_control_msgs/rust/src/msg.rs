#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to car_control_msgs__msg__CarFeedback

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CarFeedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub linear_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub angular_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub left_wheel_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub right_wheel_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub frame_type: u8,

}



impl Default for CarFeedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::CarFeedback::default())
  }
}

impl rosidl_runtime_rs::Message for CarFeedback {
  type RmwMsg = super::msg::rmw::CarFeedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        linear_velocity: msg.linear_velocity,
        angular_velocity: msg.angular_velocity,
        left_wheel_velocity: msg.left_wheel_velocity,
        right_wheel_velocity: msg.right_wheel_velocity,
        frame_type: msg.frame_type,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      linear_velocity: msg.linear_velocity,
      angular_velocity: msg.angular_velocity,
      left_wheel_velocity: msg.left_wheel_velocity,
      right_wheel_velocity: msg.right_wheel_velocity,
      frame_type: msg.frame_type,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      linear_velocity: msg.linear_velocity,
      angular_velocity: msg.angular_velocity,
      left_wheel_velocity: msg.left_wheel_velocity,
      right_wheel_velocity: msg.right_wheel_velocity,
      frame_type: msg.frame_type,
    }
  }
}


