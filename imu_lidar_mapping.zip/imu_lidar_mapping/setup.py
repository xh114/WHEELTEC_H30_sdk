from setuptools import find_packages, setup

package_name = 'imu_lidar_mapping'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='you',
    maintainer_email='you@example.com',
    description='Simple IMU+LiDAR mapping and localization demo for ROS2.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'imu_lidar_mapping_node = imu_lidar_mapping.imu_lidar_mapping:main',
        ],
    },
)
