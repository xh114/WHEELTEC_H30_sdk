from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='imu_lidar_mapping',
            executable='imu_lidar_mapping_node',
            name='imu_lidar_mapping_node',
            output='screen',
            parameters=[{
                'imu_topic': '/imu',
                'scan_topic': '/scan',
                'map_frame': 'map',
                'odom_frame': 'odom',
                'base_frame': 'base_link',
                'resolution': 0.05,
                'width': 400,
                'height': 400,
                'origin_x': -10.0,
                'origin_y': -10.0,
                'fake_motion': False,
                'fake_linear_x': 0.1,
                'fake_angular_z': 0.0,
            }],
        ),
    ])
