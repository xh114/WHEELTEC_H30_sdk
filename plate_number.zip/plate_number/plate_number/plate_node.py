import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import serial
import time

class PlateSerialNode(Node):
  def __init__(self):
    super().__init__('plate_serial_node')
    self.publisher_ = self.create_publisher(String,'license_plate',10)
    self.timer_ = self.create_timer(0.1,self.read_plate)  
    # running callback funtion (read_plate) per 0.1 second
    
    try:
      self.ser = serial.Serial(
        port = '/dev/ttyS9',
        baudrate = 115200,
        timeout = 1
        )
      self.get_logger().info("ready to recive data...")
    except Exception as e:
      self.get_logger().error(f"failure:{str(e)}")
      exit(1)
  
  # callback function
  def read_plate(self):
    if self.ser.in_waiting>0:
      plate_data = self.ser.readline().decode('utf-8').strip()
      if plate_data:
        msg = String()
        msg.data = plate_data
        self.publisher_.publish(msg)
        self.get_logger().info(f'recognition plate number:{plate_data}')
        
def main():
  rclpy.init()
  node = PlateSerialNode()
  try:
    rclpy.spin(node)
  except KeyboardInterrupt:
    node.get_logger().info("Node has been interrupted")
  finally:
    node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
  main()
  
  
  
  
  
