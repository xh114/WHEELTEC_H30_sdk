import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import time

class PlateSerialSubNode(Node):
  def __init__(self):
    super().__init__('plate_node_sub')
    self.plate_subscriber_ = self.create_subscription(
      String,
      'license_plate',  # the same as publisher
      self.plate_callback,  # callback function after reciving data
      10)
    self.get_logger().info("subscriber are ready to recive data")
    
    
  # callback funtion
  def plate_callback(self,msg):
    self.get_logger().info(f'recived data:{msg.data}')
    
def main(args = None):
  rclpy.init(args = args)
  subscribe_node = PlateSerialSubNode()
  try:
    rclpy.spin(subscribe_node)
  except KeyboardInterrupt:
    subscribe_node.get_logger().info("subscribe has been interrupted!")
  finally:
    subscribe_node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
  main()
