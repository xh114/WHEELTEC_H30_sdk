from setuptools import find_packages, setup


package_name = 'parking_robot_mapping'


setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/mapping.launch.py']),
        (
            'share/' + package_name + '/config',
            [
                'config/ekf.yaml',
                'config/slam_toolbox_online_async.yaml',
                'config/mapping.rviz',
            ],
        ),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='codex',
    maintainer_email='codex@local',
    description='Mapping helper package for virtual-chassis parking robot bring-up.',
    license='Apache-2.0',
    extras_require={'test': ['pytest']},
    entry_points={
        'console_scripts': [
            'virtual_chassis_odom = parking_robot_mapping.virtual_chassis_odom:main',
        ],
    },
)
