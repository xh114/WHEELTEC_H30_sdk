import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    pkg_share = get_package_share_directory('parking_robot_mapping')
    ekf_config = os.path.join(pkg_share, 'config', 'ekf.yaml')
    slam_config = os.path.join(pkg_share, 'config', 'slam_toolbox_online_async.yaml')
    rviz_config = os.path.join(pkg_share, 'config', 'mapping.rviz')

    return LaunchDescription([
        DeclareLaunchArgument('run_rviz', default_value='true'),
        DeclareLaunchArgument('start_lidar', default_value='true'),
        DeclareLaunchArgument('start_scan_converter', default_value='true'),
        DeclareLaunchArgument('start_imu', default_value='true'),
        DeclareLaunchArgument('motion_mode', default_value='profile'),
        DeclareLaunchArgument('fixed_linear_velocity', default_value='0.25'),
        DeclareLaunchArgument('fixed_angular_velocity', default_value='0.0'),
        DeclareLaunchArgument('imu_serial_port', default_value='/dev/wheeltec_IMU'),
        DeclareLaunchArgument('lidar_frame', default_value='velodyne_link'),
        DeclareLaunchArgument('imu_frame', default_value='gyro_link'),

        Node(
            package='lidar',
            executable='lidar_node',
            name='lidar_node',
            output='screen',
            condition=IfCondition(LaunchConfiguration('start_lidar')),
            parameters=[{
                'frame_id': LaunchConfiguration('lidar_frame'),
                'bind_address': '0.0.0.0',
                'data_port': 2368,
                'publish_period_sec': 0.1,
                'max_packets_per_publish': 90,
            }],
        ),

        Node(
            package='parking_robot_scan',
            executable='pointcloud_to_scan',
            name='pointcloud_to_scan',
            output='screen',
            condition=IfCondition(LaunchConfiguration('start_scan_converter')),
            parameters=[{
                'input_topic': '/velodyne_points',
                'output_topic': '/scan',
                'target_frame': LaunchConfiguration('lidar_frame'),
                'min_height': -0.20,
                'max_height': 0.30,
                'min_range': 0.35,
                'max_range': 20.0,
                'angle_min': -3.14159,
                'angle_max': 3.14159,
                'angle_increment': 0.00872665,
                'scan_time': 0.1,
            }],
        ),

        Node(
            package='yesense_std_ros2',
            executable='yesense_node_publisher',
            name='yesense_pub',
            output='screen',
            condition=IfCondition(LaunchConfiguration('start_imu')),
            parameters=[{
                'serial_port': LaunchConfiguration('imu_serial_port'),
                'baud_rate': 460800,
                'frame_id': LaunchConfiguration('imu_frame'),
                'driver_type': 'ros_serial',
                'imu_topic_ros': 'imu/data_raw',
                'imu_topic': 'imu_data_extend',
            }],
        ),

        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_lidar_tf',
            arguments=['0.18', '0', '0.22', '0', '0', '0', 'base_link', LaunchConfiguration('lidar_frame')],
        ),

        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_imu_tf',
            arguments=['0.00', '0', '0.12', '0', '0', '0', 'base_link', LaunchConfiguration('imu_frame')],
        ),

        Node(
            package='parking_robot_mapping',
            executable='virtual_chassis_odom',
            name='virtual_chassis_odom',
            output='screen',
            parameters=[{
                'motion_mode': LaunchConfiguration('motion_mode'),
                'fixed_linear_velocity': ParameterValue(LaunchConfiguration('fixed_linear_velocity'), value_type=float),
                'fixed_angular_velocity': ParameterValue(LaunchConfiguration('fixed_angular_velocity'), value_type=float),
                'publish_tf': False,
            }],
        ),

        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[ekf_config],
        ),

        Node(
            package='slam_toolbox',
            executable='async_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[slam_config],
        ),

        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config],
            condition=IfCondition(LaunchConfiguration('run_rviz')),
            output='screen',
        ),
    ])
