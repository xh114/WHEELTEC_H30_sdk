import math
from typing import List, Tuple

import rclpy
from geometry_msgs.msg import Quaternion, TransformStamped, TwistStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float32MultiArray
from tf2_ros import TransformBroadcaster


def yaw_to_quaternion(yaw: float) -> Quaternion:
    q = Quaternion()
    q.z = math.sin(yaw / 2.0)
    q.w = math.cos(yaw / 2.0)
    return q


class VirtualChassisOdom(Node):
    def __init__(self):
        super().__init__('virtual_chassis_odom')

        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('left_wheel_joint', 'left_wheel_joint')
        self.declare_parameter('right_wheel_joint', 'right_wheel_joint')
        self.declare_parameter('wheel_radius', 0.06)
        self.declare_parameter('wheel_base', 0.32)
        self.declare_parameter('publish_tf', True)
        self.declare_parameter('update_rate', 30.0)

        self.declare_parameter('motion_mode', 'profile')
        self.declare_parameter('fixed_linear_velocity', 0.25)
        self.declare_parameter('fixed_angular_velocity', 0.0)
        self.declare_parameter('fixed_left_wheel_speed', 0.0)
        self.declare_parameter('fixed_right_wheel_speed', 0.0)
        self.declare_parameter('profile_period', 24.0)

        self.odom_frame = str(self.get_parameter('odom_frame').value)
        self.base_frame = str(self.get_parameter('base_frame').value)
        self.left_wheel_joint = str(self.get_parameter('left_wheel_joint').value)
        self.right_wheel_joint = str(self.get_parameter('right_wheel_joint').value)
        self.wheel_radius = float(self.get_parameter('wheel_radius').value)
        self.wheel_base = float(self.get_parameter('wheel_base').value)
        self.publish_tf = bool(self.get_parameter('publish_tf').value)
        self.update_rate = float(self.get_parameter('update_rate').value)

        self.motion_mode = str(self.get_parameter('motion_mode').value)
        self.fixed_linear_velocity = float(self.get_parameter('fixed_linear_velocity').value)
        self.fixed_angular_velocity = float(self.get_parameter('fixed_angular_velocity').value)
        self.fixed_left_wheel_speed = float(self.get_parameter('fixed_left_wheel_speed').value)
        self.fixed_right_wheel_speed = float(self.get_parameter('fixed_right_wheel_speed').value)
        self.profile_period = max(1.0, float(self.get_parameter('profile_period').value))

        self.pose_x = 0.0
        self.pose_y = 0.0
        self.pose_yaw = 0.0
        self.left_wheel_pos = 0.0
        self.right_wheel_pos = 0.0
        self.last_time = self.get_clock().now()
        self.start_time = self.last_time

        self.odom_pub = self.create_publisher(Odometry, '/wheel/odom', 10)
        self.chassis_pub = self.create_publisher(TwistStamped, '/virtual_chassis/cmd_feedback', 10)
        self.wheel_pub = self.create_publisher(Float32MultiArray, '/virtual_chassis/wheel_speeds', 10)
        self.joint_pub = self.create_publisher(JointState, '/joint_states', 10)
        self.tf_broadcaster = TransformBroadcaster(self)

        self.timer = self.create_timer(1.0 / self.update_rate, self.timer_callback)

        self.get_logger().info(
            'virtual_chassis_odom started. '
            f'motion_mode={self.motion_mode}, update_rate={self.update_rate:.1f} Hz'
        )

    def timer_callback(self) -> None:
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds / 1e9
        if dt <= 0.0:
            return

        linear_x, angular_z, left_speed, right_speed = self._compute_motion(now)

        self.pose_x += linear_x * math.cos(self.pose_yaw) * dt
        self.pose_y += linear_x * math.sin(self.pose_yaw) * dt
        self.pose_yaw += angular_z * dt
        self.pose_yaw = math.atan2(math.sin(self.pose_yaw), math.cos(self.pose_yaw))

        self.left_wheel_pos += left_speed * dt
        self.right_wheel_pos += right_speed * dt

        self._publish_odometry(now, linear_x, angular_z)
        self._publish_feedback(now, linear_x, angular_z, left_speed, right_speed)
        self._publish_joint_states(now, left_speed, right_speed)

        if self.publish_tf:
            self._publish_tf(now)

        self.last_time = now

    def _compute_motion(self, now) -> Tuple[float, float, float, float]:
        if self.motion_mode == 'stationary':
            return 0.0, 0.0, 0.0, 0.0

        if self.motion_mode == 'fixed':
            if self.fixed_left_wheel_speed != 0.0 or self.fixed_right_wheel_speed != 0.0:
                linear_x = self.wheel_radius * (self.fixed_left_wheel_speed + self.fixed_right_wheel_speed) / 2.0
                angular_z = self.wheel_radius * (self.fixed_right_wheel_speed - self.fixed_left_wheel_speed) / self.wheel_base
                return linear_x, angular_z, self.fixed_left_wheel_speed, self.fixed_right_wheel_speed
            left_speed, right_speed = self._vw_to_wheels(self.fixed_linear_velocity, self.fixed_angular_velocity)
            return self.fixed_linear_velocity, self.fixed_angular_velocity, left_speed, right_speed

        elapsed = (now - self.start_time).nanoseconds / 1e9
        phase = elapsed % self.profile_period
        segments: List[Tuple[float, float, float]] = [
            (0.30, 0.00, 7.0),
            (0.22, 0.40, 5.0),
            (0.30, 0.00, 6.0),
            (0.22, -0.45, 4.0),
            (0.18, 0.00, 2.0),
        ]

        accumulator = 0.0
        for linear_x, angular_z, duration in segments:
            accumulator += duration
            if phase <= accumulator:
                left_speed, right_speed = self._vw_to_wheels(linear_x, angular_z)
                return linear_x, angular_z, left_speed, right_speed

        return 0.0, 0.0, 0.0, 0.0

    def _vw_to_wheels(self, linear_x: float, angular_z: float) -> Tuple[float, float]:
        left = (linear_x - angular_z * self.wheel_base / 2.0) / self.wheel_radius
        right = (linear_x + angular_z * self.wheel_base / 2.0) / self.wheel_radius
        return left, right

    def _publish_odometry(self, now, linear_x: float, angular_z: float) -> None:
        msg = Odometry()
        msg.header.stamp = now.to_msg()
        msg.header.frame_id = self.odom_frame
        msg.child_frame_id = self.base_frame
        msg.pose.pose.position.x = self.pose_x
        msg.pose.pose.position.y = self.pose_y
        msg.pose.pose.orientation = yaw_to_quaternion(self.pose_yaw)
        msg.twist.twist.linear.x = linear_x
        msg.twist.twist.angular.z = angular_z

        msg.pose.covariance = [0.0] * 36
        msg.twist.covariance = [0.0] * 36
        msg.pose.covariance[0] = 0.03
        msg.pose.covariance[7] = 0.03
        msg.pose.covariance[35] = 0.05
        msg.twist.covariance[0] = 0.02
        msg.twist.covariance[35] = 0.04
        self.odom_pub.publish(msg)

    def _publish_feedback(self, now, linear_x: float, angular_z: float, left_speed: float, right_speed: float) -> None:
        twist = TwistStamped()
        twist.header.stamp = now.to_msg()
        twist.header.frame_id = self.base_frame
        twist.twist.linear.x = linear_x
        twist.twist.angular.z = angular_z
        self.chassis_pub.publish(twist)

        wheel = Float32MultiArray()
        wheel.data = [float(left_speed), float(right_speed)]
        self.wheel_pub.publish(wheel)

    def _publish_joint_states(self, now, left_speed: float, right_speed: float) -> None:
        msg = JointState()
        msg.header.stamp = now.to_msg()
        msg.name = [self.left_wheel_joint, self.right_wheel_joint]
        msg.position = [self.left_wheel_pos, self.right_wheel_pos]
        msg.velocity = [left_speed, right_speed]
        self.joint_pub.publish(msg)

    def _publish_tf(self, now) -> None:
        tf_msg = TransformStamped()
        tf_msg.header.stamp = now.to_msg()
        tf_msg.header.frame_id = self.odom_frame
        tf_msg.child_frame_id = self.base_frame
        tf_msg.transform.translation.x = self.pose_x
        tf_msg.transform.translation.y = self.pose_y
        tf_msg.transform.rotation = yaw_to_quaternion(self.pose_yaw)
        self.tf_broadcaster.sendTransform(tf_msg)


def main(args=None):
    rclpy.init(args=args)
    node = VirtualChassisOdom()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
