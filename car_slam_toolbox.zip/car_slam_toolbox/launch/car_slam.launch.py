import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time')
    slam_params_file = LaunchConfiguration('slam_params_file')

    default_params_file = os.path.join(
        get_package_share_directory('car_slam_toolbox'),
        'config',
        'mapper_params_online_async.yaml'
    )
    bringup_launch = os.path.join(
        get_package_share_directory('car_odometry'),
        'launch',
        'car_bringup.launch.py'
    )

    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation clock if true.'
        ),
        DeclareLaunchArgument(
            'slam_params_file',
            default_value=default_params_file,
            description='Full path to the slam_toolbox parameter file.'
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(bringup_launch)
        ),
        Node(
            package='slam_toolbox',
            executable='async_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[
                slam_params_file,
                {'use_sim_time': use_sim_time},
            ],
        ),
    ])
