# car_control

```mermaid
flowchart LR
  subgraph ELF2_3588 [ELF2-3588 (上位机)]
    A1[ROS 发布者<br/>(teleop / planner) ]
    A2[car_control_node<br/>(订阅 /cmd_vel, 发布 /car_feedback)]
    A3[Serial device<br/>(/dev/ttyUSB0, 115200 8N1)]
  end

  subgraph STM32 [STM32 小车驱动板]
    B1[USART3 PNS 解析<br/>(0xAA 0xBB 0xCC ...)]
    B2[控制逻辑 / Drive_Motor]
    B3[RS485 接口 (USART2/6/7)<br/>(9600, 9E1) ]
    B4[电机驱动器 (下位)]
  end

  subgraph ROS_topics [ROS 话题]
    T1[/cmd_vel (Twist)]
    T2[/car_feedback (Twist) ]
  end

  %% 上行命令流程
  A1 -->|发布 Twist| T1
  T1 -->|订阅| A2
  A2 -->|构造 PNS 帧 (控制命令)| A3
  A3 -.物理串口 TX/RX.-> B1
  B1 -->|解析命令| B2
  B2 -->|Modbus/RS485 写寄存器| B3
  B3 -->|RS485| B4

  %% 反馈流程
  B4 -->|速度/状态反馈 (RS485)| B3
  B3 -->|上报给控制逻辑| B2
  B2 -->|构造 PNS 反馈帧| B1
  B1 -.PNS over USART3.-> A3
  A3 -->|serial read| A2
  A2 -->|发布 Twist 反馈| T2
  T2 -->|订阅者可读| A1

  %% 注明关键协议与参数
  classDef proto fill:#fff7e6,stroke:#f39c12;
  A3,B1,B3 class proto;
  %% labels
  A3:::proto
  B1:::proto
  B3:::proto
```

ROS2 package for STM32 motor drive host communication.

## 代码分析

- STM32 `Auv_Car_control` 代码使用 `USART3` (`huart3`) 作为上位机通信接口，波特率 `115200`，8N1。
- `USART2`、`USART6` 和 `UART7` 作为 RS485 串口，波特率 `9600`，9 数据位，偶校验，分别控制三个电机通道。
- `control.c` 使用 Modbus RTU 命令发送电机速度：
  - 通过 `RS485_Send_Data`, `RS485_Send_Data_6`, `RS485_Send_Data_7` 发送写寄存器命令 `0x06`。
  - 通过 `RS485_Receive_Data` 等读取反馈寄存器 `0x03`。
- `pns.c` 实现了主机与 STM32 之间的 PNS 包通信协议：
  - 接收包头 `0xAA 0xBB 0xCC`，然后读取长度、命令、速度、角速度等字段。
  - 通过 `Mcu_To_Pns()` 发送回路速度反馈。

## 与 ELF2 3588 的通信方式

1. 物理接口：ELF2 3588 需要通过串口和 STM32 的 `USART3` 连接。
2. 协议层：STM32 端使用 PNS 自定义协议，与主控板交换运动指令和反馈数据。
3. 电机控制链路：STM32 负责将上位机命令转换为 RS485/Modbus 命令，驱动电机。

因此，ELF2 3588 只需要负责“上位机串口 + ROS 节点”，STM32 负责“下位机 RS485 + 电机控制”。

## 使用说明

1. 在 ELF2 3588 上安装 `pyserial`

```bash
pip install pyserial
```

2. 通过 ROS2 启动节点：

```bash
ros2 run car_control car_control_node --ros-args -p serial_port:=/dev/ttyS1
```

3. 发布速度指令：

```bash
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist '{linear: {x: 0.2}, angular: {z: 0.1}}'
```

4. 读取反馈：

```bash
ros2 topic echo /car_feedback
```

## 目录结构

- `package.xml`
- `setup.py`
- `setup.cfg`
- `resource/car_control`
- `src/car_control/car_control_node.py`
