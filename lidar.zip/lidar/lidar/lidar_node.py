import rclpy
from rclpy.node import Node
import socket
import struct
import numpy as np
from sensor_msgs.msg import PointCloud2, PointField
from std_msgs.msg import Header
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy

# -------------------------- VLP-16 激光参数（手册标准） --------------------------
VERTICAL_ANGLES = np.array([
    -15.0, 1.0, -13.0, 3.0, -11.0, 5.0, -9.0, 7.0,
    -7.0, 9.0, -5.0, 11.0, -3.0, 13.0, -1.0, 15.0
], dtype=np.float32)
VERTICAL_ANGLES_RAD = np.radians(VERTICAL_ANGLES)
VERTICAL_CORR_M = np.array([
    11.2, -0.7, 9.7, -2.2, 8.1, -3.7, 6.6, -5.1,
    5.1, -6.6, 3.7, -8.1, 2.2, -9.7, 0.7, -11.2
], dtype=np.float32) / 1000.0

# 雷达网络参数
DATA_PORT = 2368
PACKET_LEN = 1248

class VLP16Listener(Node):
    def __init__(self):
        super().__init__('lidar_node')
        # 创建点云发布者
        #self.publisher_ = self.create_publisher(PointCloud2, 'velodyne_points', 10)
        sensor_qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history = QoSProfile.history.KEEP_LAST,
            depth=10)
        self.publisher_ = self.create_publisher(PointCloud2, 'velodyne_points', sensor_qos)
        self.get_logger().info("✅ VLP-16 ROS2节点启动,监听端口2368,雷达IP:192.168.2.201")

        # 创建UDP Socket，绑定本机所有网卡
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(('0.0.0.0', DATA_PORT))
        self.sock.settimeout(1.0)

        # 100Hz定时器，定时接收数据
        self.timer = self.create_timer(0.01, self.timer_callback)

    def create_point_cloud2(self, points):
        """生成ROS2格式的PointCloud2消息"""
        msg = PointCloud2()
        header = Header()
        header.frame_id = "velodyne_link"
        header.stamp = self.get_clock().now().to_msg()
        msg.header = header

        # 定义点云字段（x/y/z/intensity）
        msg.fields = [
            PointField(name='x', offset=0, datatype=PointField.FLOAT32, count=1),
            PointField(name='y', offset=4, datatype=PointField.FLOAT32, count=1),
            PointField(name='z', offset=8, datatype=PointField.FLOAT32, count=1),
            PointField(name='intensity', offset=12, datatype=PointField.FLOAT32, count=1)
        ]
        msg.is_bigendian = False
        msg.point_step = 16  # 每个点4个float32，共16字节
        msg.row_step = msg.point_step * len(points)
        msg.width = len(points)
        msg.height = 1
        msg.is_dense = False
        msg.data = points.tobytes()
        return msg

    def parse_vlp16_packet(self, data):
        """解析单包VLP-16数据,返回点云数组"""
        points = []
        #data_blocks = data[42:]  # 跳过前42字节协议头
        for i in range(12):  # 每包12个数据块
            block = data[i*100 : (i+1)*100]
            flag = struct.unpack('<H', block[0:2])[0]
            if flag != 0xFFEE:
                continue  # 无效数据块跳过
            # 方位角（单位：度，转弧度）
            azi_raw = struct.unpack('<H', block[2:4])[0]
            azi_rad = np.radians(azi_raw / 100.0)
            # 解析块内32个点
            for j in range(32):
                p = block[4 + j*3 : 4 + (j+1)*3]
                dist_raw, intensity = struct.unpack('<HB', p)
                if dist_raw == 0:
                    continue  # 无效距离点跳过
                dist = dist_raw * 0.002  # 距离转米（精度2mm）
                laser_id = j % 16
                omega = VERTICAL_ANGLES_RAD[laser_id]
                # 球面坐标转笛卡尔坐标
                x = -dist * np.cos(omega) * np.sin(azi_rad)
                y = -dist * np.cos(omega) * np.cos(azi_rad)
                z = dist * np.sin(omega) + VERTICAL_CORR_M[laser_id]
                points.append([x, y, z, intensity / 255.0])
        return np.array(points, dtype=np.float32)

    def timer_callback(self):
        try:
            data, _ = self.sock.recvfrom(2048)
            if len(data) != PACKET_LEN:
                return
            points = self.parse_vlp16_packet(data)
            if len(points) == 0:
                return
            # 发布点云
            pc2_msg = self.create_point_cloud2(points)
            self.publisher_.publish(pc2_msg)
        except socket.timeout:
            self.get_logger().warn("⚠️  未收到雷达数据，请检查网络/防火墙")
        except Exception as e:
            self.get_logger().error(f"❌ 数据解析错误: {e}")

def main(args=None):
    rclpy.init(args=args)
    vlp16_listener = VLP16Listener()
    rclpy.spin(vlp16_listener)
    # 资源释放
    vlp16_listener.sock.close()
    vlp16_listener.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()